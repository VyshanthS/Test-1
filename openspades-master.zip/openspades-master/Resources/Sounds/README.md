
This directory contains sound files used by OpenSpades.

Some files are replaced with placeholder sound files due to license restrictions.
If you find suitable GPL-compatible sound files, please add them to the source tree.
(But please do not add large (> 500KB) sound files!)

As a side note: assets of a commercial game are not guaranteed to be GPL-compatible
even if the source code of the game is licensed under GPL. The examples include
OpenSpades and Quake 3: Arena.

Placeholder sound files are suffixed with `.weak` so that files from the non-free
paks take precedence.
